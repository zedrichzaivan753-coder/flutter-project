# Simple Flutter Counter App

A simple, clean counter app built with Flutter.

## Features

- **Increment**: Tap the + button to increase the counter
- **Decrement**: Tap the - button to decrease the counter (minimum is 0)
- **Reset**: Press the Reset button to set the counter back to 0
- **Material Design 3**: Modern UI with Material Design

## Getting Started

### Prerequisites

- Flutter SDK installed ([Install Flutter](https://flutter.dev/docs/get-started/install))
- An Android emulator or physical device for testing

### Running the App

1. Navigate to the project directory:
   ```
   cd "z:\Downloads\SIMPLE FLUTTER PROJECT"
   ```

2. Get dependencies:
   ```
   flutter pub get
   ```

3. Run the app:
   ```
   flutter run
   ```

## Project Structure

```
lib/
└── main.dart          # Main app file with counter logic
pubspec.yaml          # Project dependencies and configuration
```

## How It Works

The app uses a `StatefulWidget` to manage the counter state:
- `_counter` variable stores the current count
- `setState()` rebuilds the UI when the counter changes
- Three buttons control increment, decrement, and reset

Enjoy your counter app! 🚀

Transfer to Another Computer - YES! ✅
You can absolutely copy the project folder to a USB flash drive and run it on another computer. Here's what to do:

Steps:

Copy simple_counter folder to your USB flash drive
On the other computer:
Install Flutter SDK (same process as before)
Copy the project folder from USB to the other computer
Open terminal in the project folder
Run: flutter pub get (to restore dependencies - this is important!)
Run: flutter run or flutter run -d android (if device connected)
What you DON'T need to transfer:

.dart_tool folder (regenerated with flutter pub get)
build folder (recreated automatically)
pubspec.lock (regenerated)
What gets transferred:

lib - Your code ✅
pubspec.yaml - Dependencies list ✅
android/, ios/, windows/ - Platform configs ✅
README.md, .gitignore - Documentation ✅
Simple summary: The project is 100% portable - just copy the folder and run flutter pub get on the new computer!